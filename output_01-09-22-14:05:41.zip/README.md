# heif2jpg
Convert .heif image to .jpg using Github Actions.
